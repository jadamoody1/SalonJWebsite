class Customer {
    name = null;
    email = null;
    style = null;
    date = null;
    additionalInfo = null;

    constructor(name, email, style, date, info) {
        this.name = name;
        this.email = email;
        this.style = style;
        this.additionalInfo = info;
    }
}

module.exports = Customer;