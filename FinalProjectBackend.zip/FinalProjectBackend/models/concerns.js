class Concerns {
    name = null;
    email = null;
    concern = null;

    constructor(name, email, concern) {
        this.name = name;
        this.email = email;
        this.concern = concern;
    }
}

module.exports = Concerns;