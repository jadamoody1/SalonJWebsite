const customerController = require('./controllers/controller.js');

const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
const port = 9020;

app.use(bodyParser.json());
app.use(cors());

app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});
app.get('/customers', customerController.getCustomersAPI);
app.post('/customer', customerController.createCustomerAPI);
app.post('/concern', customerController.createConcernAPI);
