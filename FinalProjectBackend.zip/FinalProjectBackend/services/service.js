const Customer = require('../models/classes')
const Concern = require('../models/concerns')

let customerList = []
let concernList = []

function createCustomer(name, email, style, date, info) {
    let newCustomer = new Customer(name, email, style, date, info);
    customerList.push(newCustomer);
    return newCustomer;
}

function getCustomerList() {
    return customerList;
}

function createConcern(name, email, concern){
    let newConcern = new Concern(name, email, concern);
    concernList.push(newConcern);
    return newConcern;
}

module.exports ={
    createCustomer,
    customerList,
    getCustomerList,
    concernList,
    createConcern
}

