const customerServices = require('../services/service.js')

function createCustomerAPI(req, res) {
    const newCustomer = customerServices.createCustomer(req.body.name, req.body.email, req.body.style, req.body.date, req.body.additionalInfo);
    res.json(newCustomer);
}

function createConcernAPI(req, res){
    const newConcern = customerServices.createConcern(req.body.name, req.body.email, req.body.concern);
    res.json(newConcern);
}

function getCustomersAPI(req, res) {
    res.json(customerServices.getCustomerList())
}

module.exports ={
    createCustomerAPI,
    getCustomersAPI,
    createConcernAPI
}

