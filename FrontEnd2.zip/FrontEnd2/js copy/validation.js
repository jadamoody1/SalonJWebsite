function validateBookNow() {
    let name = document.forms['customerForm']['fullname'].value;
    let nameCSS = document.getElementById('fullname');
    let email = document.forms['customerForm']['email'].value;
    let emailCSS = document.getElementById('email');
    if (name == '') {
        nameCSS.style.border = '3px solid red';
        alert("Must enter name.");
        return false;
    }
    if (email == ''){
        emailCSS.style.border = '3px solid red';
        alert("Must enter email.")
        return false;
    }

}

function validateConcern() {
    let name = document.forms['concernForm']['fullname'].value;
    let nameCSS = document.getElementById('fullname');
    let email = document.forms['concernForm']['email'].value;
    let emailCSS = document.getElementById('email');
    if (name == '') {
            nameCSS.style.border = '3px solid red';
            alert("Must enter name.");
            return false;
        }
        if (email == ''){
            emailCSS.style.border = '3px solid red';
            alert("Must enter email.")
            return false;
        }


}

