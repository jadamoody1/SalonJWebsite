class Customer {
    name = null;
    email = null;
    style = null;
    date = null;
    additionalInfo = null;

    constructor(name, email, style, date, info) {
        this.name = name;
        this.email = email;
        this.style = style;
        this.additionalInfo = info;
    }
}

class Concern {
    name = null;
    email = null;
    concern = null;

    constructor(name, email, concern) {
        this.name = name;
        this.email = email;
        this.concern = concern;
    }

}