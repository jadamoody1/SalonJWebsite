const domain = "http://chronos.cs.elon.edu/jmoody7/api";

const customerPath = "customer";
const concernPath = "concern";

const baseCustomerURL = domain + "/" + customerPath;
const baseConcernURL = domain + "/" + concernPath;

const createCustomerURL = baseCustomerURL;
const createConcernURL = baseConcernURL;