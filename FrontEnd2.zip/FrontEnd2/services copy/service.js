function buildFetchOptions(method,bodyObject) {
    let fetchOptions = {};
    fetchOptions.method = method.toLowerCase();
    if (fetchOptions.method == 'post') {
        fetchOptions.body = JSON.stringify(bodyObject);
        fetchOptions.headers = {"Content-Type":"application/json"};
    }
    console.log(fetchOptions)
    return fetchOptions;
}
async function makeAPICall(url,method,idParam,bodyObject) {
    let fetchOptions = buildFetchOptions(method,bodyObject);
    if (idParam && idParam != null) {
        url += "/"+idParam;
    }
    let apiResponse = await fetch(url,fetchOptions);
    if (apiResponse.status != 200) return undefined;
    let apiResponseJSON = await apiResponse.json();
    return apiResponseJSON;
}

async function addConcern(name, email, concern) {
    let newConcern = new Concern(name, email, concern);
    let concernResponse = await makeAPICall(createConcernURL, "post", undefined, newConcern);
}

async function addCustomer(name, email, style, date, additionalInfo) {
    let newCustomer = new Customer(name, email, style, date, additionalInfo);
    let customerResponse = await makeAPICall(createCustomerURL,"post",undefined,newCustomer);
    console.log('Customer API Response', customerResponse)
}