function submitCustomer() {
    const formInputs = document.getElementById('customerForm').elements;
    const checkedStyle = document.querySelectorAll("input[type='radio']:checked");
    const form = document.getElementById('form');
    const name = formInputs['fullname'].value;
    const email = formInputs['email'].value;
    const style = checkedStyle.length > 0 ? checkedStyle[0].value : '';
    const date = formInputs['date'].value;
    const additionalInfo = formInputs['additionalInfo'].value;
    addCustomer(name, email, style, date, additionalInfo)
    form.innerHTML = `<h1> Hi ${name}. You have scheduled your appointment for ${date}. See you then!</h1>`

}

function submitConcern() {
     const formInputs = document.getElementById('concernForm').elements;
     const name = formInputs['fullname'].value;
     const email = formInputs['email'].value;
     const concern = formInputs['questionConcern'].value;
     addConcern(name, email, concern)
     form.innerHTML = '<h1> Thank you for for submitting your question/concern. We will get back to you. </h1> '


}


